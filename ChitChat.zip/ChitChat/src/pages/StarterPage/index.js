import React from 'react';

function Index(props) {

    document.title = " Starter Page | ChitChat - Responsive Bootstrap 5 Admin Dashboard"
    return (
        <React.Fragment>
            
        </React.Fragment>
    );
}

export default Index;